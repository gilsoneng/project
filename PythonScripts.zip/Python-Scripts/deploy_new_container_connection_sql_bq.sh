#!/usr/bin/env bash

echo "preparing..."
export GCLOUD_PROJECT=bigqueryunilever
export INSTANCE_REGION=southamerica-east1
#export INSTANCE_ZONE=southamerica-east1-b
export CLUSTER_NAME=cluster-2
export CONTAINER_NAME=container-sql-tabela-dim-kit

echo "building containers"
gcloud builds submit -t gcr.io/${GCLOUD_PROJECT}/${CONTAINER_NAME} k8s_connection_sql_bq


