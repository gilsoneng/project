# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#from dateutil.relativedelta import relativedelta
#import datetime
#import math
import pandas as pd
#from pandas import DataFrame
from google.oauth2 import service_account
from google.cloud import bigquery
#import numpy as np
#import os
#from datetime import datetime as datetimenow
#from multiprocessing import Pool
import pyodbc
import logging

def save_bigquery(df, dataset, table):
    """Import a csv file into BigQuery"""
    logging.info(table)
    #if os.environ.get('PRODUCTION'):
    client = bigquery.Client()
    #else:
    #client = bigquery.Client.from_service_account_json("storage2bq.json")

    table_ref = client.dataset(dataset).table(table)
    job_config = bigquery.LoadJobConfig()
    job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE
    job_config.autodetect = True
    job_config.schema = [
            bigquery.SchemaField("ListaId", "FLOAT")
    ]
    load_job = client.load_table_from_dataframe(df,
                                                table_ref,
                                                job_config=job_config)
    # Waits for table load to complete.
    load_job.result()

server = '10.34.1.4' 
database = 'ODS_UNILEVER' 
username = 'BIGQUERY_BI' 
password = 'AN2 6optimist hurts a backpack' 
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = cnxn.cursor()
#df = pd.read_sql(sql,cnxn)
tableorigem = 'Pedido_Produto'
#sql = 'SELECT * FROM ODS_UNILEVER.infrashop.' + tableorigem
#
table = tableorigem
#dataset = "infrashop"
#save_bigquery(df, dataset, table)
#cursor.execute()

sql = 'SELECT DISTINCT(CAST(DAT_CARGA as DATE)) FROM ODS_UNILEVER.infrashop.Pedido_Produto'

dfdata = pd.DataFrame([])

dfdata = pd.read_sql(sql,cnxn)
dfdata['Data'] = pd.read_sql(sql,cnxn)

dfdata['DataSTR'] = pd.read_sql(sql,cnxn).astype(str)

dfdata = dfdata.sort_values(by='Data', ascending=True)

for data in dfdata['Data']:
    print data
    print 'comecando leitura'
    sql = "SELECT * FROM ODS_UNILEVER.infrashop.Pedido_Produto Where CAST(DAT_CARGA as DATE) = CAST('{}' as DATE)".format(data)
    table = tableorigem+'_'+str(data).replace('-','')
    dataset = "infrashop_raw"
    df = pd.read_sql(sql,cnxn)
    df['ListaId'] = df['ListaId'].astype(float)
    print 'leu'
    save_bigquery(df, dataset, table)
    print 'gravou'



