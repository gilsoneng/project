#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 02:14:05 2020

@author: projbigqueryunl_intcomp_gilson
"""

import pandas as pd
from google.oauth2 import service_account
from google.cloud import bigquery
import pyodbc
import logging
from datetime import date
from google.cloud.exceptions import NotFound

import time
import datetime
import pytz
import sys
import math


def read_CAAS():
    login_timeout = 90
    server = '10.34.1.4' 
    database = 'BI_UNILEVER' 
    username = 'BIGQUERY_BI' 
    password = 'AN2 6optimist hurts a backpack' 
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password, timeout=login_timeout)
    cursor = cnxn.cursor()
    #tableorigem = "'DIM_DISTRIBUIDOR'"
    ntrymax = 12
    condition = False
    sql = "SELECT MAX(DT_INSERT) as MAXDATE FROM ADD_CAAS.dw.CTRL_BIUNILEVER Where NM_DATSET in ('DIM_CLIENTE','DIM_DISTRIBUIDOR','DIM_ENDERECO_PEDIDO', 'DIM_KIT','DIM_PEDIDO','DIM_PRODUTO','DIM_TIPO_PAGAMENTO') and CAST(DT_INSERT as DATE) = (SELECT CAST(MAX(DT_INSERT) as DATE) FROM ADD_CAAS.dw.CTRL_BIUNILEVER)"
    ntry = 0
    utc = pytz.utc
    while (ntry < ntrymax and condition == False):
        df = pd.read_sql(sql,cnxn)
        datadf = datetime.datetime.strptime(str(df['MAXDATE'][0]),'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=utc)
        
        br_sp = pytz.timezone('America/Sao_Paulo')
        datenow = datetime.datetime.now(tz=br_sp).replace(tzinfo=utc)
        #print(f'datadf: {datadf}')
        #print(f'datenow: {datenow}')
        condition = abs(datadf - datenow).days == 0 and (math.floor(datadf.hour / 6) == math.floor(datenow.hour / 6))
        if condition == True:
            return condition
        time.sleep(300)
        ntry += 1
        #print(f'ntry: {ntry}')

    return condition

def del_data(dataproject, datasetprojectbi, table):
    
    client = bigquery.Client(project=dataproject)
    table_ref = client.dataset(datasetprojectbi).table(table)
    client.delete_table(table_ref)  # API request
    #try:
    #    client.delete_table(table_ref)
    #except:  
    #    print(f'table not found: {table_ref}')  
    #with pytest.raises(NotFound):
    #    client.get_table(table_ref)  # API request

def save_bigquery(df, dataset, table):
    """Import a csv file into BigQuery"""
    logging.info(table)
    client = bigquery.Client()
    
    table_ref = client.dataset(dataset).table(table)
    job_config = bigquery.LoadJobConfig()
    job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE
    #job_config.autodetect = True
    job_config.schema = [
        bigquery.SchemaField("ComboId", "FLOAT"),
        bigquery.SchemaField("SiteId", "INTEGER"),
        bigquery.SchemaField("Codigo", "STRING"),
        bigquery.SchemaField("NotaFiscal", "STRING"),
        bigquery.SchemaField("Quantidade", "INTEGER"),
        bigquery.SchemaField("Valor", "FLOAT"),
        bigquery.SchemaField("DataInsercao", "TIMESTAMP"),
        bigquery.SchemaField("HASH", "STRING"),
        bigquery.SchemaField("DAT_CARGA", "TIMESTAMP"),
        bigquery.SchemaField("Migracao", "FLOAT", "NULLABLE", "PedidoId", "INTEGER"),
        bigquery.SchemaField("ComboId", "FLOAT"),
        bigquery.SchemaField("SiteId", "INTEGER"),
        bigquery.SchemaField("Codigo", "STRING"),
        bigquery.SchemaField("NotaFiscal", "STRING"),
        bigquery.SchemaField("Quantidade", "INTEGER"),
        bigquery.SchemaField("Valor", "FLOAT"),
        bigquery.SchemaField("DataInsercao", "TIMESTAMP"),
        bigquery.SchemaField("HASH", "STRING"),
        bigquery.SchemaField("DAT_CARGA", "TIMESTAMP"),
        bigquery.SchemaField("Migracao", "FLOAT"),
    ]
    load_job = client.load_table_from_dataframe(df,
                                                table_ref,
                                                job_config=job_config)
    # Waits for table load to complete.
    load_job.result()
    
def getTablesNames(project, datasetlabel):
    listatabelas = []
    client = bigquery.Client()

    datatables = list(client.list_tables(project + '.' + datasetlabel))

    for datatable in datatables:
        nometabela = datatable.table_id
        listatabelas.append(nometabela)

    return listatabelas

def connect(request):
    if read_CAAS() == False:
        raise Exception("Condição de sincronização insatisfeita")
    #SQL_ATTR_CONNECTION_TIMEOUT = 113
    login_timeout = 90
    #connection_timeout = 90
    server = '10.34.1.4' 
    database = 'ODS_UNILEVER' 
    username = 'BIGQUERY_BI' 
    password = 'AN2 6optimist hurts a backpack' 
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password, timeout=login_timeout)
    cursor = cnxn.cursor()
    tableorigem = 'PedidoSkuFaturado'

    datefield = "DAT_CARGA"
    sql = f'SELECT DISTINCT(CAST({datefield} as DATE)) FROM ODS_UNILEVER.infrashop.{tableorigem}'

    dfdata = pd.DataFrame([])
    logging.info('inicio leitura datas')
    dfdata = pd.read_sql(sql,cnxn)
    dfdata['Data'] = pd.read_sql(sql,cnxn)

    dfdata['DataSTR'] = pd.read_sql(sql,cnxn).astype(str)
    logging.info('leu datas')
    dfdata = dfdata.sort_values(by='Data', ascending=False)
    data_atual = date.today()
    dfdata = dfdata[dfdata['Data']<data_atual]

    tablenamesfull = getTablesNames('bigqueryunilever','infrashop_raw')

    tablenames = []
    
    for tablenamesf in tablenamesfull:
        if tableorigem in tablenamesf:
            tablenames.append(tablenamesf)

    tablenamesdelete = []

    datatables = []

    for data in dfdata['Data']:
        datatables.append(f'{tableorigem}_' + str(data).replace('-',''))
        print('tabela sql: ', f'{tableorigem}_' + str(data).replace('-',''))

    for tname in tablenames:
        if tname not in datatables:
            print('tabela deletada: ', tname)
            del_data('bigqueryunilever', 'infrashop_raw', tname)

    for data in dfdata['Data']:
        print('data: ', data)
        logging.info(data)
        logging.info('comecando leitura')
        sql = f"SELECT * FROM ODS_UNILEVER.infrashop.{tableorigem} Where CAST({datefield}"+" as DATE) = CAST('{}' as DATE)".format(data)
        table = tableorigem+'_'+str(data).replace('-','')
        dataset = "infrashop_raw"
        df = pd.read_sql(sql,cnxn)
        #df['ListaId'] = df['ListaId'].astype(float)
        df.head()
        logging.info('leu')
        save_bigquery(df, dataset, table)
        print('gravou')

if __name__ == "__main__":
    connect("request")
