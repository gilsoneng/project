#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/pipeline_bgqtosql
echo pasta
echo dockerinicio
docker run container_pipeline_bgqtosql:latest
echo dockerfile
