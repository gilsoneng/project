#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 02:14:05 2020

@author: projbigqueryunl_intcomp_gilson
"""

import pandas as pd
from google.oauth2 import service_account
from google.cloud import bigquery
import pyodbc
import logging
import numpy as np
from sqlalchemy import create_engine, event
import urllib
from sqlalchemy.types import Integer, String, Unicode, Boolean, DateTime, Float, Numeric
import datetime
import time
import pytz
import sys
import math

def get_data(dataproject, datasetprojectbi, table, clausule = "", columns = '*'):
    query = f"SELECT {columns} FROM `{dataproject}.{datasetprojectbi}.{table}` {clausule}"
    datatable = pd.read_gbq(
            query,
            project_id=dataproject,
            dialect="standard")
    return datatable


def pipeline(request):
    server = '10.34.1.4' 
    database = 'BI_UNILEVER' 
    username = 'BIGQUERY_BI' 
    password = 'AN2 6optimist hurts a backpack'
    db_params = urllib.parse.quote_plus('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    engine = create_engine("mssql+pyodbc:///?odbc_connect={}".format(db_params))
    
    @event.listens_for(engine, 'before_cursor_execute')
    def receive_before_cursor_execute(conn, cursor, statement, params, context, executemany):
        if executemany:
            cursor.fast_executemany = True
    print("Date Getted")
    dfdate = get_data(dataproject = "bigqueryunilever", datasetprojectbi = "infrashop_clean", table = "Tabela_Calculo_6_Fato", columns = 'DISTINCT CAST(DT_INS AS DATE)')

    dfdate['NaT'] = dfdate['f0_'].apply(lambda x: True if type(x) == pd._libs.tslibs.nattype.NaTType else False)

    dfdate = dfdate[dfdate['NaT']!= True].drop('NaT', axis =1).sort_values(by=['f0_'])

    for date in dfdate['f0_']:
        date = str(date).replace(' 00:00:00','')
        print(f"lendo FAT_PEDIDO_FATURADO BigQUery: {date}")
        df1 = get_data("bigqueryunilever", "infrashop_clean", "Tabela_Calculo_6_Fato", clausule = f"Where CAST(DT_INS AS DATE) = '{date}'")
        columns1=['SK_PEDIDO', 'SK_FRONT', 'SK_PRODUTO', 'SK_KIT', 'SK_DATA', 'SK_CANAL_VENDA',
                 'SK_ENDERECO', 'SK_CLIENTE', 'SK_DISTRIBUIDOR', 'SK_TIPO_PAGAMENTO', 'CD_NOTA_FISCAL']
        columns2=['ind_bonificado', 'QTD_ITEM_NF', 'VLR_ITEM_NF', 'VLR_TOTAL_NF', 'QTD_ITEM_A_ITEM_PS', 'QTD_ITEM_A_ITEM_PSK',
                 'VLR_ITEM_A_ITEM_PS', 'VLR_ITEM_A_ITEM_PSK', 'FATOR_QTD_PS', 'FATOR_QTD_PSK',
                 'FATOR_BONIFICADO_PS', 'FATOR_BONIFICADO_PSK']
        df1['ind_bonificado'] = df1['ind_bonificado'].astype(int)
        df1[columns1] = df1[columns1].fillna(-2)
        df1[columns2] = df1[columns2].fillna(0)
        df1['FLG_ORIGEM'] = df1['FLG_ORIGEM'].fillna(3)
        df1["DT_INS"] = df1["DT_INS"].astype('datetime64[ns]')
        print(f"exluindo FAT_PEDIDO_FATURADO: {date} do servidor")
        engine.execute(f"DELETE FROM FAT_PEDIDO_FATURADO WHERE FLG_ORIGEM=3 and CAST(DT_INS AS DATE) = '{date}'")
        print(f"escrevendo FAT_PEDIDO_FATURADO: {date} no servidor")
        engine.fast_executemany = True
        df1.to_sql('FAT_PEDIDO_FATURADO',con=engine,index=False,if_exists="append",schema="dw",
                   dtype={   "CD_NOTA_FISCAL": Integer(),
                             "ind_bonificado": Integer(),
                             "QTD_ITEM_NF": Integer(),
                             "VLR_ITEM_NF": Numeric(10,2),
                             "VLR_TOTAL_NF": Numeric(10,2),
                             "QTD_ITEM_A_ITEM_PS": Numeric(10,2),
                             "QTD_ITEM_A_ITEM_PSK": Numeric(10,2),
                             "VLR_ITEM_A_ITEM_PS": Numeric(10,2),
                             "VLR_ITEM_A_ITEM_PSK": Numeric(10,2),
                             "FATOR_QTD_PS": Numeric(10,4),
                             "FATOR_QTD_PSK": Numeric(10,4),
                             "FATOR_BONIFICADO_PS": Numeric(10,4),
                             "FATOR_BONIFICADO_PSK": Numeric(10,4),
                             "DT_INS": DateTime(),
                             "FLG_ORIGEM": Integer()})

    database = 'ADD_CAAS'
    dbcaas_params = urllib.parse.quote_plus('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    engine2 = create_engine("mssql+pyodbc:///?odbc_connect={}".format(dbcaas_params))
    #ID = 124
    br_sp = pytz.timezone('America/Sao_Paulo')
    #DT_INSERT = datetime.datetime.timestamp(datetime.datetime.now())
    f = '%Y-%m-%d %H:%M:%S'
    utc = pytz.utc
    DT_INSERT = datetime.datetime.now(tz=br_sp).replace(tzinfo=utc).strftime(f)
    NM_WORKSPACE = "FAT"
    NM_DATSET = "FAT_PEDIDO_FATURADO"
    df2list = [[DT_INSERT,NM_WORKSPACE,NM_DATSET]]
    df2 = pd.DataFrame(df2list, columns=["DT_INSERT","NM_WORKSPACE","NM_DATSET"])
    df2.to_sql('CTRL_BIUNILEVER',con=engine2,index=False,if_exists="append",schema="dw",
           dtype={   "DT_INSERT": DateTime(),
                     "NM_WORKSPACE": String(),
                     "NM_DATSET": String()})
    

if __name__ == "__main__":
    pipeline("request")
