import pyodbc 

server = '10.34.1.4' 
database = 'ODS_UNILEVER' 
username = 'BIGQUERY_BI' 
password = 'AN2 6optimist hurts a backpack' 
cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = cnxn.cursor()

#connection = pyodbc.connect(
#    Driver="SQL Driver",
#    Server= "ServerName",
#    Database="ODS_UNILEVER",
#    UID="BIGQUERY_BI",
#    PWD="AN2 6optimist hurts a backpack",
#    Trusted_Connection="yes"
#)

cursor.execute('SELECT BandeiraId, Nome, Status, HASH, DAT_CARGA FROM ODS_UNILEVER.infrashop.Bandeira')

