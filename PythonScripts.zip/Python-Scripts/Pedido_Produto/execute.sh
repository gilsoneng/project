#!/usr/bin/env bash
cd ~/Desktop/Python-Scripts/connection_sql_bq/ && sudo docker run -it container_connection_sql_bq:latest
