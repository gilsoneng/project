#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/Pedido_Produto
echo pasta
echo dockerinicio
docker run container_sql_tabela_pedido_produto:latest
echo dockerfile
