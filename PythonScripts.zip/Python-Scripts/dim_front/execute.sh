#!/usr/bin/env bash
cd ~/Desktop/Python-Scripts/connection_sql_bq/ && sudo docker run -it container_sql_tabela_dim_front:latest
