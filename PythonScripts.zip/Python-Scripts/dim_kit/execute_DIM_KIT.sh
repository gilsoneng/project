#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/dim_kit
echo pasta
echo dockerinicio
docker run container_sql_tabela_dim_kit:latest
echo dockerfile
