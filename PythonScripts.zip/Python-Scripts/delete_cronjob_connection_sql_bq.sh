#!/usr/bin/env bash

echo "preparing..."
export GCLOUD_PROJECT=bigqueryunilever
export INSTANCE_REGION=southamerica-east1
#export INSTANCE_ZONE=southamerica-east1-b
export CLUSTER_NAME=cluster-2
export CONTAINER_NAME=container-sql-tabela-dim-kit

echo "setup"
gcloud config set compute/region ${INSTANCE_REGION}

echo "get credentials"
gcloud container clusters get-credentials ${CLUSTER_NAME} --region ${INSTANCE_REGION}

echo "delete cronjob"
kubectl delete cronjob dim-kit-cronjob

#echo "remove container"
gcloud container images delete gcr.io/${GCLOUD_PROJECT}/${CONTAINER_NAME} --force-delete-tags --quiet
