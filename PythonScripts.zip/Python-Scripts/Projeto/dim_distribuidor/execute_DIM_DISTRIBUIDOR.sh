#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/dim_distribuidor
echo pasta
echo dockerinicio
docker run container_sql_tabela_dim_distribuidor:latest
echo dockerfile
