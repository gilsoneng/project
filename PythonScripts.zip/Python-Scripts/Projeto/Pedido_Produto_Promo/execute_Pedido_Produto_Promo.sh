#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/Pedido_Produto_Promo
echo pasta
echo dockerinicio
docker run container_sql_tabela_pedido_produto_promo:latest
echo dockerfile
