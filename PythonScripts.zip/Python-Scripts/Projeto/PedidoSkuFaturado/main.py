#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 02:14:05 2020

@author: projbigqueryunl_intcomp_gilson
"""

import pandas as pd
from google.oauth2 import service_account
from google.cloud import bigquery
import pyodbc
import logging

def save_bigquery(df, dataset, table):
    """Import a csv file into BigQuery"""
    logging.info(table)
    client = bigquery.Client()
    
    table_ref = client.dataset(dataset).table(table)
    job_config = bigquery.LoadJobConfig()
    job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE
    job_config.autodetect = True
    load_job = client.load_table_from_dataframe(df,
                                                table_ref,
                                                job_config=job_config)
    # Waits for table load to complete.
    load_job.result()
    
def connect(request):
    #SQL_ATTR_CONNECTION_TIMEOUT = 113
    login_timeout = 90
    #connection_timeout = 90
    server = '10.34.1.4' 
    database = 'ODS_UNILEVER' 
    username = 'BIGQUERY_BI' 
    password = 'AN2 6optimist hurts a backpack' 
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password, timeout=login_timeout)
    cursor = cnxn.cursor()
    tableorigem = 'PedidoSkuFaturado'
    sql = 'SELECT * FROM ODS_UNILEVER.infrashop.' + tableorigem
    table = tableorigem
    dataset = "infrashop_raw"
    df = pd.read_sql(sql,cnxn)
    logging.info(f'leu tabela = {table}')
    save_bigquery(df, dataset, table)
    logging.info(f'gravou tabela = {table}')

if __name__ == "__main__":
    connect("request")
