#!/bin/bash
echo inicio
cd ~/Desktop/Python-Scripts/Pedido_PedidoStatus
echo pasta
echo dockerinicio
docker run container_sql_tabela_pedido_pedidostatus:latest
echo dockerfile
